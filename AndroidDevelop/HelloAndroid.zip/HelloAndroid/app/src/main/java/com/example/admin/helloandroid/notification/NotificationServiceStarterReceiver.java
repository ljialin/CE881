package com.example.admin.helloandroid.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Jialin Liu on 20/10/2016.
 * CSEE, University of Essex
 * jialin.liu@essex.ac.uk
 */

public class NotificationServiceStarterReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationReceiver.setupAlarm(context);
    }
}
